Copyright (c) 2011 Diego J. Brengi <brengi at inti gob ar>
Copyright (c) 2011 Salvador E. Tropea <salvador at inti gob ar>
Copyright (c) 2010 Christian Huy 
Copyright (c) 2011 Instituto Nacional de Tecnolog�a Industrial

##############################################################################
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA
#
##############################################################################

S3-POWER
========

Free hardware design: Triple power supply module for FPGA.

Authors: Christian Huy, Diego J. Brengi, Salvador E. Tropea
Electr�nica e Inform�tica
Instituto Nacional de Tecnolog�a Industrial
Laboratorio de Desarrollo Electr�nico con Software Libre
Buenos Aires, Argentina
email: {brengi, salvador} at inti.gob.ar

This hardware design and all related files are licensed under the
GNU General Public License (GPL).

Description:
S3-POWER is a power supply module for FPGA (Spartan 3/3E family), based
on TPS75003. It is used to power up the S3PROTO-MINI FPGA Board.

DIRECTORIES:
kicad/design/s3power:  Kicad Files.
kicad/libs:  Kicad Lib.
doc/:  General documentation.
doc/fotos/: Some photos.
kicad/design/adaptador:  Kicad Files. TPS75003 adapter
